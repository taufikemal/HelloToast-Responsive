package com.example.hellotoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnToast, btnCount ;
    private TextView txtHasil ;
    private int angka;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToast = findViewById(R.id.btn_toast);
        btnCount = findViewById(R.id.btn_count);
        txtHasil = findViewById(R.id.txt_hasil);


        btnCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = txtHasil.getText().toString();
                angka = Integer.parseInt(text);
                angka++ ;
                txtHasil.setText(String.valueOf(angka));
            }
        });


        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "HELLO TOAST", Toast.LENGTH_SHORT).show();
            }
        });

    }
}